<?php

$rtlSUB = array();
$finals = '';
$rphf = array (
);
$half = array (
);
$pref = array (
);
$blwf = array (
  2608 => 58030,
  2613 => 58028,
  2617 => 58029,
);
$pstf = array (
  2607 => 58032,
);

 
?>